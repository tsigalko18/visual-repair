package issta2018_visual_repair.testsuite_addressbook40;

import static org.junit.Assert.assertFalse;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class AddressBookRemoveMultipleGroupsTest {

	private WebDriver driver;

	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.get("http://localhost:8888/addressbook/addressbookv4.0/index.php");
	}

	@Test
	public void testAddressBookRemoveMultipleGroups() throws Exception {
		driver.findElement(By.linkText("groups")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[1]")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[2]")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[3]")).click();
		driver.findElement(By.name("delete")).click();
		driver.findElement(By.linkText("group page")).click();
		assertFalse(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("Group1"));
		assertFalse(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("Group2"));
		assertFalse(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("Group3"));
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

}