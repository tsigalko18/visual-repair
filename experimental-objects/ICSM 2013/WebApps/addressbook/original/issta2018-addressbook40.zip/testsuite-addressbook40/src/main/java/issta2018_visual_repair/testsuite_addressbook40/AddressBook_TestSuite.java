package issta2018_visual_repair.testsuite_addressbook40;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({

	AddressBookAddAddressBookTest.class,
	AddressBookSearchAddressBookNameTest.class,
	AddressBookSearchAddressBookEmailTest.class,
	AddressBookSearchAddressBookTelephoneNegativeTest.class,
	AddressBookAddGroupTest.class,
	AddressBookAssignToGroupTest.class,
	AddressBookSearchByGroupTest.class,
	AddressBookCheckBirthdayInfoTest.class,
	AddressBookCheckAddressBookTest.class,
	AddressBookPrintAddressBookTest.class,
	AddressBookEditAddressBookTest.class,
	AddressBookEditGroupTest.class,
	AddressBookUnassignFromGroupTest.class,
	AddressBookRemoveGroupTest.class,
	AddressBookRemoveAddressBookTest.class,
	AddressBookAddMultipleAddressBookTest.class,
	AddressBookSearchMultipleAddressBookNameTest.class,
	AddressBookAddMultipleGroupsTest.class,
	AddressBookAssignToMultipleGroupsTest.class,
	AddressBookSearchByMultipleGroupsTest.class,
	AddressBookCheckMultipleBirthdaysInfoTest.class,
	AddressBookCheckMultipleAddressBookTest.class,
	AddressBookPrintMultipleAddressBookTest.class,
	AddressBookEditMultipleAddressBookTest.class,
	AddressBookEditMultipleGroupsTest.class,
	AddressBookUnassignFromMultipleGroupsTest.class,
	AddressBookRemoveMultipleGroupsTest.class,
	AddressBookRemoveMultipleAddressBookTest.class,
	
})

public class AddressBook_TestSuite {}
