package issta2018_visual_repair.testsuite_addressbook40;

import static org.junit.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class AddressBookEditMultipleGroupsTest {

	private WebDriver driver;

	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		driver.get("http://localhost:8888/addressbook/addressbookv4.0/index.php");
	}

	@Test
	public void testAddressBookEditMultipleGroups() throws Exception {
		driver.findElement(By.linkText("groups")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[1]")).click();
		driver.findElement(By.name("edit")).click();
		driver.findElement(By.name("group_name")).clear();
		driver.findElement(By.name("group_name")).sendKeys("NewGroup1");
		driver.findElement(By.name("group_header")).clear();
		driver.findElement(By.name("group_header")).sendKeys("New Header1");
		driver.findElement(By.name("group_footer")).clear();
		driver.findElement(By.name("group_footer")).sendKeys("New Footer1");
		driver.findElement(By.name("update")).click();
		driver.findElement(By.linkText("group page")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[1]")).click();
		driver.findElement(By.name("edit")).click();
		driver.findElement(By.name("group_name")).clear();
		driver.findElement(By.name("group_name")).sendKeys("NewGroup2");
		driver.findElement(By.name("group_header")).clear();
		driver.findElement(By.name("group_header")).sendKeys("New Header2");
		driver.findElement(By.name("group_footer")).clear();
		driver.findElement(By.name("group_footer")).sendKeys("New Footer2");
		driver.findElement(By.name("update")).click();
		driver.findElement(By.linkText("group page")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]/input[1]")).click();
		driver.findElement(By.name("edit")).click();
		driver.findElement(By.name("group_name")).clear();
		driver.findElement(By.name("group_name")).sendKeys("NewGroup3");
		driver.findElement(By.name("group_header")).clear();
		driver.findElement(By.name("group_header")).sendKeys("New Header3");
		driver.findElement(By.name("group_footer")).clear();
		driver.findElement(By.name("group_footer")).sendKeys("New Footer3");
		driver.findElement(By.name("update")).click();
		driver.findElement(By.linkText("group page")).click();
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]")).getText().contains("NewGroup1"));
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]")).getText().contains("NewGroup2"));
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]/form[2]")).getText().contains("NewGroup3"));
		driver.findElement(By.linkText("home")).click();
		new Select(driver.findElement(By.name("group"))).selectByVisibleText("NewGroup1");
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Header1"));
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Footer1"));
		new Select(driver.findElement(By.name("group"))).selectByVisibleText("NewGroup2");
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Header2"));
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Footer2"));
		new Select(driver.findElement(By.name("group"))).selectByVisibleText("NewGroup3");
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Header3"));
		assertTrue(driver.findElement(By.xpath("html/body/div[1]/div[4]")).getText().contains("New Footer3"));
	}

	@After
	public void tearDown() throws Exception {
		driver.quit();
	}

}
